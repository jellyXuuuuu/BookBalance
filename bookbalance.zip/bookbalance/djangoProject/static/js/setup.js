$.ajaxSetup({headers: {"X-CSRFToken": '{{ csrf_token }}'}});
